
import React from 'react';
import { PipelineStatus } from '../types';
import { PIPELINE_STEPS } from '../constants';
import { CheckCircle2, Circle, Loader2, AlertCircle } from 'lucide-react';

interface ProcessingPipelineProps {
  status: PipelineStatus;
  progress: number;
  currentTask: string;
}

const ProcessingPipeline: React.FC<ProcessingPipelineProps> = ({ status, progress, currentTask }) => {
  const getStepStatus = (stepStatus: string) => {
    if (status === PipelineStatus.ERROR) return 'error';
    if (status === PipelineStatus.DONE) return 'completed';

    const stepOrder = ['preprocessing', 'transcribing', 'rendering', 'done'];
    
    // worker.py의 step 문자열이나 message 내용을 기반으로 현재 단계 확인
    const taskLower = currentTask.toLowerCase();
    let currentStep = 'preprocessing';
    
    if (taskLower.includes('render') || taskLower.includes('fluidsynth')) currentStep = 'rendering';
    else if (taskLower.includes('transk') || taskLower.includes('transcribing')) currentStep = 'transcribing';
    else if (taskLower.includes('complete') || taskLower.includes('done')) currentStep = 'done';

    const currentIndex = stepOrder.indexOf(currentStep);
    const thisStepIndex = stepOrder.indexOf(stepStatus);

    if (currentIndex > thisStepIndex) return 'completed';
    if (currentIndex === thisStepIndex) return 'current';
    return 'pending';
  };

  return (
    <div className="space-y-8 py-4">
      <div className="relative">
        <div className="absolute top-4 left-4 right-4 h-0.5 bg-slate-800"></div>
        <div 
          className="absolute top-4 left-4 h-0.5 bg-indigo-500 transition-all duration-700 ease-in-out"
          style={{ width: `${progress}%` }}
        ></div>

        <div className="flex justify-between relative">
          {PIPELINE_STEPS.map((step) => {
            const stepStatus = getStepStatus(step.status);
            return (
              <div key={step.status} className="flex flex-col items-center group">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 transition-all duration-300 ${
                  stepStatus === 'completed' ? 'bg-indigo-500 text-white' :
                  stepStatus === 'current' ? 'bg-slate-900 border-2 border-indigo-500 text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.5)]' :
                  stepStatus === 'error' ? 'bg-red-500 text-white' :
                  'bg-slate-800 border-2 border-slate-700 text-slate-500'
                }`}>
                  {stepStatus === 'completed' && <CheckCircle2 size={16} />}
                  {stepStatus === 'current' && <Loader2 size={16} className="animate-spin" />}
                  {stepStatus === 'pending' && <Circle size={12} fill="currentColor" />}
                  {stepStatus === 'error' && <AlertCircle size={16} />}
                </div>
                <span className={`mt-3 text-[10px] font-bold uppercase tracking-wider ${
                  stepStatus === 'current' ? 'text-indigo-400' : 'text-slate-500'
                }`}>
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 flex items-center justify-between shadow-inner">
        <div className="flex items-center gap-4">
          <div className="relative w-10 h-10">
             <div className="absolute inset-0 rounded-full border-2 border-slate-800"></div>
             <div className="absolute inset-0 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin"></div>
          </div>
          <div className="max-w-[200px] sm:max-w-xs overflow-hidden">
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Status</p>
            <p className="text-sm text-white font-medium truncate">{currentTask}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Progress</p>
          <p className="text-2xl font-black text-indigo-400 mono">{Math.round(progress)}%</p>
        </div>
      </div>
    </div>
  );
};

export default ProcessingPipeline;
