
import React, { useState, useRef } from 'react';
import { Upload, Youtube, FileAudio, Link2, X, Play } from 'lucide-react';

interface UploaderProps {
  onProcess: (item: File | string) => void;
  isProcessing: boolean;
}

const Uploader: React.FC<UploaderProps> = ({ onProcess, isProcessing }) => {
  const [activeTab, setActiveTab] = useState<'file' | 'url'>('file');
  const [url, setUrl] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    else if (e.type === "dragleave") setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onProcess(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onProcess(e.target.files[0]);
    }
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) onProcess(url.trim());
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl overflow-hidden shadow-2xl">
      <div className="flex border-b border-slate-700/50">
        <button
          onClick={() => setActiveTab('file')}
          className={`flex-1 py-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
            activeTab === 'file' ? 'bg-slate-700 text-white border-b-2 border-indigo-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Upload size={18} />
          Local Audio
        </button>
        <button
          onClick={() => setActiveTab('url')}
          className={`flex-1 py-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
            activeTab === 'url' ? 'bg-slate-700 text-white border-b-2 border-indigo-500' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Youtube size={18} />
          YouTube URL
        </button>
      </div>

      <div className="p-8">
        {activeTab === 'file' ? (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`relative border-2 border-dashed rounded-xl p-12 transition-all flex flex-col items-center justify-center text-center ${
              dragActive ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-600 bg-slate-900/40'
            } ${isProcessing ? 'opacity-50 pointer-events-none' : ''}`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".mp3,.wav,.m4a"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-6 shadow-inner">
              <FileAudio className="text-indigo-400" size={32} />
            </div>
            <h3 className="text-lg font-semibold text-slate-200 mb-2">
              Drop your audio here
            </h3>
            <p className="text-sm text-slate-400 mb-6 max-w-xs">
              Supports MP3, WAV, and M4A formats. Maximum file size 50MB.
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-full text-sm font-bold transition-all shadow-lg hover:shadow-indigo-500/20 active:scale-95"
            >
              Browse Files
            </button>
          </div>
        ) : (
          <form onSubmit={handleUrlSubmit} className="space-y-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-500">
                <Link2 size={20} />
              </div>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full bg-slate-900/60 border border-slate-700 rounded-xl pl-12 pr-4 py-4 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all shadow-inner"
              />
            </div>
            <p className="text-xs text-slate-500 px-2 italic">
              Note: This will extract the high-quality 192kbps audio stream directly from the source.
            </p>
            <button
              type="submit"
              disabled={!url || isProcessing}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white py-4 rounded-xl text-sm font-bold transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <Play size={18} fill="currentColor" />
              Analyze & Transcribe
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Uploader;
