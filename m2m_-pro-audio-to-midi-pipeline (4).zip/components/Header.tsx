
import React from 'react';
import { Cpu, Database, User } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="h-16 border-b border-slate-800 flex items-center justify-between px-6 lg:px-12 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
      <div className="flex items-center gap-4">
        <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
          <span className="text-white font-black text-xs">M2M</span>
        </div>
        <div className="hidden sm:flex items-center gap-6">
          <NavLink icon={<Cpu size={14} />} label="Transkun Engine" />
          <NavLink icon={<Database size={14} />} label="SF2 Library" />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-tighter">Engine Ready</span>
        </div>
        <button className="p-2 text-slate-400 hover:text-white transition-colors">
          <User size={20} />
        </button>
      </div>
    </header>
  );
};

const NavLink = ({ icon, label }: { icon: React.ReactNode, label: string }) => (
  <a href="#" className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors uppercase tracking-widest">
    {icon}
    {label}
  </a>
);

export default Header;
