
import { PedalParams, SoundFont } from './types';

export const DEFAULT_PEDAL_PARAMS: PedalParams = {
  sustainTolerance: 0.2,
  energySmooth: 0.5,
  lowFreqCut: 500,
  lowEnergyWeight: 0.6,
  fluxWeight: 0.4,
  onThreshold: 1.0,
  offThreshold: 0.7,
  minEventLen: 0.08,
  mergeGap: 0.08,
};

export const SF2_LIBRARY: SoundFont[] = [
  { id: 'grand-piano', name: 'Steinway Grand Piano', path: '/usr/share/sounds/sf2/FluidR3_GM.sf2' },
  { id: 'upright-piano', name: 'Classic Upright Piano', path: '/usr/share/sounds/sf2/FluidR3_GM.sf2' },
];

export const PIPELINE_STEPS = [
  { status: 'preprocessing', label: 'Preparing Audio' },
  { status: 'transcribing', label: 'AI Transcription' },
  { status: 'rendering', label: 'WAV Rendering' },
  { status: 'done', label: 'Finalizing' },
];
