
import { PedalParams, BackendResponse } from '../types';

export class ApiService {
  private baseUrl: string;

  constructor(url: string) {
    let sanitizedUrl = url.trim();
    if (sanitizedUrl && !/^https?:\/\//i.test(sanitizedUrl)) {
      sanitizedUrl = `https://${sanitizedUrl}`;
    }
    this.baseUrl = sanitizedUrl.replace(/\/$/, '');
  }

  getHealthUrl(): string {
    return `${this.baseUrl}/health`;
  }

  private async safeFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    try {
      const response = await fetch(input, init);
      
      if (response.status === 404) {
        const path = new URL(input.toString()).pathname;
        throw new Error(`Endpoint Not Found (404): '${path}' 경로가 백엔드에 존재하지 않습니다. FastAPI의 @app.post('/submit/file') 설정을 확인하세요.`);
      }

      if (response.status === 502 || response.status === 503 || response.status === 504) {
        throw new Error(`Server Awakening (Status ${response.status}): Render 서버가 깨어나는 중입니다. 잠시 후 다시 시도해주세요.`);
      }

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server Error (${response.status}): ${errorText || response.statusText}`);
      }
      return response;
    } catch (error: any) {
      if (error instanceof TypeError) {
        const message = `Connection Failed (CORS/Network Error).\n\n브라우저 보안 정책(CORS)에 의해 차단되었습니다. FastAPI 백엔드에 CORSMiddleware가 올바르게 설정되었는지 확인하세요.`;
        throw new Error(message);
      }
      throw error;
    }
  }

  async ping(): Promise<boolean> {
    try {
      const response = await fetch(this.getHealthUrl(), { method: 'GET', mode: 'cors' });
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * 이제 모든 입력(로컬 파일, 추출된 URL 음원)은 File/Blob 형태로 전달됩니다.
   */
  async startJob(audioData: File | Blob, params: PedalParams, sf2: string): Promise<string> {
    const formData = new FormData();
    formData.append('file', audioData, "input_audio.wav"); // filename 지정
    formData.append('params', JSON.stringify(params));
    formData.append('sf2', sf2);

    // 사용자가 성공을 확인한 유일한 엔드포인트 사용
    const endpoint = `${this.baseUrl}/submit/file`;

    const response = await this.safeFetch(endpoint, {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();
    if (!data.job_id) {
      throw new Error("백엔드 응답에 'job_id'가 없습니다.");
    }
    return data.job_id;
  }

  async pollStatus(jobId: string): Promise<BackendResponse> {
    const response = await this.safeFetch(`${this.baseUrl}/status/${jobId}`, {
      method: 'GET',
    });
    return await response.json() as BackendResponse;
  }

  getDownloadUrl(jobId: string, type: 'midi' | 'wav'): string {
    return `${this.baseUrl}/download/${jobId}/${type}`;
  }
}
