
export enum PipelineStatus {
  IDLE = 'IDLE',
  WAKING_UP = 'WAKING_UP',
  PROCESSING = 'processing', // worker.py의 state="processing"
  DONE = 'completed',        // worker.py의 state="completed"
  ERROR = 'failed'           // worker.py의 state="failed"
}

export interface SoundFont {
  id: string;
  name: string;
  path: string;
}

export interface PedalParams {
  sustainTolerance: number;
  energySmooth: number;
  lowFreqCut: number;
  lowEnergyWeight: number;
  fluxWeight: number;
  onThreshold: number;
  offThreshold: number;
  minEventLen: number;
  mergeGap: number;
}

export interface ProcessingState {
  status: PipelineStatus;
  progress: number;
  currentTask: string;
  error?: string;
  results?: {
    midiUrl: string;
    wavUrl?: string;
    analysis?: string;
    pedalCount: number;
  };
}

// worker.py의 update_job 인자들과 구조를 일치시킴
export interface BackendResponse {
  job_id: string;
  status: 'processing' | 'completed' | 'failed'; 
  step: 'preprocessing' | 'transcribing' | 'rendering' | 'done' | 'error';
  progress: number;
  message: string;
  result?: {
    midi_path: string;
    wav_path: string;
  };
  error?: string;
}
