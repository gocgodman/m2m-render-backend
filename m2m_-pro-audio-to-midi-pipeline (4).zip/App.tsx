
import React, { useState, useCallback, useMemo } from 'react';
import { PipelineStatus, ProcessingState, PedalParams, BackendResponse } from './types';
import { DEFAULT_PEDAL_PARAMS } from './constants';
import { analyzeAudioWithGemini } from './services/geminiService';
import { ApiService } from './services/apiService';
import Header from './components/Header';
import ConfigSidebar from './components/ConfigSidebar';
import Uploader from './components/Uploader';
import ProcessingPipeline from './components/ProcessingPipeline';
import ResultsPanel from './components/ResultsPanel';
import { Music, AlertTriangle, RefreshCcw, Globe } from 'lucide-react';

const App: React.FC = () => {
  const [params, setParams] = useState<PedalParams>(DEFAULT_PEDAL_PARAMS);
  const [selectedSf2, setSelectedSf2] = useState('grand-piano');
  const [backendUrl, setBackendUrl] = useState('https://m2m-render-backend.onrender.com');
  const [state, setState] = useState<ProcessingState>({
    status: PipelineStatus.IDLE,
    progress: 0,
    currentTask: 'Waiting for input...'
  });

  const api = useMemo(() => new ApiService(backendUrl), [backendUrl]);

  const resetState = () => {
    setState({
      status: PipelineStatus.IDLE,
      progress: 0,
      currentTask: 'Waiting for input...'
    });
  };

  const fetchAudioBlob = async (url: string): Promise<Blob> => {
    setState(prev => ({ ...prev, currentTask: '외부 URL에서 음원 데이터 다운로드 중...' }));
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("URL 접근에 실패했습니다.");
      return await response.blob();
    } catch (err) {
      throw new Error("브라우저 보안(CORS) 정책으로 인해 외부 URL에서 직접 다운로드할 수 없습니다. 파일을 다운로드한 후 직접 업로드해 주세요.");
    }
  };

  const processAudio = async (input: File | string) => {
    try {
      setState({ status: PipelineStatus.WAKING_UP, progress: 2, currentTask: '환경 준비 중...' });

      let audioBlob: File | Blob;
      if (typeof input === 'string') {
        audioBlob = await fetchAudioBlob(input);
      } else {
        audioBlob = input;
      }

      // Gemini 분석 시작
      let musicalAnalysis = "Musical analysis pending...";
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(audioBlob);
      });
      base64Promise.then(base64 => {
        analyzeAudioWithGemini(base64, audioBlob.type).then(res => { musicalAnalysis = res; });
      });

      setState(prev => ({ ...prev, status: PipelineStatus.PROCESSING, progress: 10, currentTask: '서버로 데이터 전송 중...' }));
      const jobId = await api.startJob(audioBlob, params, selectedSf2);

      // worker.py 상태 추적 시작
      let finished = false;
      while (!finished) {
        const jobStatus: BackendResponse = await api.pollStatus(jobId);

        if (jobStatus.status === 'completed') {
          finished = true;
          setState({
            status: PipelineStatus.DONE,
            progress: 100,
            currentTask: 'Completed',
            results: {
              midiUrl: api.getDownloadUrl(jobId, 'midi'),
              wavUrl: api.getDownloadUrl(jobId, 'wav'),
              analysis: musicalAnalysis,
              pedalCount: 0 
            }
          });
        } else if (jobStatus.status === 'failed') {
          throw new Error(jobStatus.error || jobStatus.message || 'Pipeline failed during execution');
        } else {
          // 진행 중 상태 업데이트 (worker.py의 step과 message 반영)
          setState(prev => ({
            ...prev,
            status: PipelineStatus.PROCESSING,
            progress: (jobStatus.progress || 0) * 100,
            currentTask: jobStatus.message || `Step: ${jobStatus.step}`
          }));
          await new Promise(r => setTimeout(r, 3000)); // 3초 간격 폴링
        }
      }
    } catch (err: any) {
      setState(prev => ({
        ...prev,
        status: PipelineStatus.ERROR,
        error: err.message || 'An unexpected error occurred.'
      }));
    }
  };

  const handleProcess = useCallback((item: File | string) => {
    processAudio(item);
  }, [params, selectedSf2, backendUrl, api]);

  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden text-slate-200">
      <ConfigSidebar
        params={params}
        setParams={setParams}
        selectedSf2={selectedSf2}
        setSelectedSf2={setSelectedSf2}
        backendUrl={backendUrl}
        setBackendUrl={setBackendUrl}
        api={api}
      />

      <main className="flex-1 flex flex-col bg-slate-950 overflow-y-auto">
        <Header />

        <div className="max-w-4xl mx-auto w-full p-6 lg:p-12 space-y-12">
          {state.status === PipelineStatus.IDLE && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-500/10 rounded-2xl mb-4">
                  <Music className="text-indigo-500" size={32} />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight text-white lg:text-5xl">
                  Audio to <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-emerald-400">Pro MIDI</span>
                </h1>
                <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
                   Upload your audio or enter a URL. <br/>
                   <span className="text-white font-mono">Transkun AI</span> generates professional piano scores.
                </p>
              </div>
              <Uploader onProcess={handleProcess} isProcessing={false} />
            </div>
          )}

          {(state.status === PipelineStatus.WAKING_UP || state.status === PipelineStatus.PROCESSING) && (
            <div className="space-y-12 py-12 animate-in zoom-in-95 duration-300">
               <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-2">Processing Pipeline</h2>
                  <p className="text-slate-400 text-sm italic font-medium">{state.currentTask}</p>
               </div>
               <ProcessingPipeline 
                 status={state.status} 
                 progress={state.progress} 
                 currentTask={state.currentTask} 
               />
            </div>
          )}

          {state.status === PipelineStatus.DONE && <ResultsPanel state={state} onReset={resetState} />}

          {state.status === PipelineStatus.ERROR && (
            <div className="bg-red-500/5 border border-red-500/20 rounded-3xl p-8 md:p-12 text-center space-y-8 animate-in slide-in-from-top-4 duration-500">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto ring-8 ring-red-500/5">
                <AlertTriangle size={40} className="text-red-500" />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-white">Execution Failed</h3>
                <div className="text-red-400/90 text-sm bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-xl mx-auto whitespace-pre-wrap text-left font-mono leading-relaxed shadow-xl overflow-x-auto max-h-60">
                  {state.error}
                </div>
              </div>
              <button onClick={resetState} className="bg-red-600 hover:bg-red-500 text-white px-8 py-3 rounded-xl font-bold flex items-center justify-center gap-2 mx-auto transition-all active:scale-95">
                <RefreshCcw size={18} /> Try Again
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
