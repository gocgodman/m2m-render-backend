
import React, { useState } from 'react';
import { PedalParams } from '../types';
import { SF2_LIBRARY } from '../constants';
import { ApiService } from '../services/apiService';
import { Settings, Zap, SlidersHorizontal, Globe, CheckCircle2, XCircle, Loader2, Activity } from 'lucide-react';

interface ConfigSidebarProps {
  params: PedalParams;
  setParams: (p: PedalParams) => void;
  selectedSf2: string;
  setSelectedSf2: (s: string) => void;
  backendUrl: string;
  setBackendUrl: (url: string) => void;
  api: ApiService;
}

const ConfigSidebar: React.FC<ConfigSidebarProps> = ({ 
  params, setParams, selectedSf2, setSelectedSf2, backendUrl, setBackendUrl, api 
}) => {
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const updateParam = (key: keyof PedalParams, val: number) => {
    setParams({ ...params, [key]: val });
  };

  const handleTestConnection = async () => {
    setTestStatus('loading');
    const alive = await api.ping();
    setTestStatus(alive ? 'success' : 'error');
    setTimeout(() => setTestStatus('idle'), 3000);
  };

  return (
    <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-6 overflow-y-auto space-y-8 flex flex-col h-full shadow-2xl z-20">
      <div className="flex-1 space-y-8">
        <div>
          <div className="flex items-center gap-2 mb-6 text-indigo-400">
            <Globe size={18} />
            <h2 className="font-bold uppercase tracking-wider text-xs">Connectivity</h2>
          </div>
          <div className="space-y-4">
            <label className="block">
              <span className="text-[10px] font-bold text-slate-500 uppercase mb-2 block tracking-widest">Backend Endpoint</span>
              <div className="relative group">
                <input
                  type="text"
                  value={backendUrl}
                  onChange={(e) => setBackendUrl(e.target.value)}
                  placeholder="https://app.onrender.com"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder:text-slate-600 transition-all group-hover:border-slate-600"
                />
              </div>
            </label>
            <button
              onClick={handleTestConnection}
              disabled={testStatus === 'loading'}
              className={`w-full py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                testStatus === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                testStatus === 'error' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
            >
              {testStatus === 'loading' ? <Loader2 size={14} className="animate-spin" /> : 
               testStatus === 'success' ? <CheckCircle2 size={14} /> : 
               testStatus === 'error' ? <XCircle size={14} /> : <Activity size={14} />}
              {testStatus === 'loading' ? 'Testing...' : 
               testStatus === 'success' ? 'Connected' : 
               testStatus === 'error' ? 'Failed' : 'Test Connection'}
            </button>
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-6 text-indigo-400">
            <Settings size={20} />
            <h2 className="font-bold uppercase tracking-wider text-xs">Synthesis</h2>
          </div>

          <div className="space-y-4">
            <label className="block">
              <span className="text-[10px] font-bold text-slate-500 uppercase mb-2 block tracking-widest">WAV Renderer</span>
              <select
                value={selectedSf2}
                onChange={(e) => setSelectedSf2(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all hover:border-slate-600 appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%22%20width%3D%2216%22%20height%3D%2216%22%20fill%3D%22none%22%3E%3Cpath%20stroke%3D%22%23475569%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%20stroke-width%3D%222%22%20d%3D%22m4%206%204%204%204-4%22%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_0.5rem_center] bg-no-repeat pr-10"
              >
                <option value="none">MIDI Only (Fastest)</option>
                {SF2_LIBRARY.map((sf) => (
                  <option key={sf.id} value={sf.id}>{sf.name}</option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-6 text-emerald-400">
            <SlidersHorizontal size={20} />
            <h2 className="font-bold uppercase tracking-wider text-xs">Nuance Control</h2>
          </div>

          <div className="space-y-6">
            <ParamSlider
              label="On Threshold"
              value={params.onThreshold}
              min={0.2}
              max={2.0}
              step={0.1}
              onChange={(v) => updateParam('onThreshold', v)}
            />
            <ParamSlider
              label="Off Threshold"
              value={params.offThreshold}
              min={0}
              max={1.5}
              step={0.05}
              onChange={(v) => updateParam('offThreshold', v)}
            />
            <ParamSlider
              label="Merge Gap"
              value={params.mergeGap}
              min={0.01}
              max={0.3}
              step={0.01}
              suffix="s"
              onChange={(v) => updateParam('mergeGap', v)}
            />
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-800 shrink-0">
        <div className="flex items-center gap-2 mb-4 text-amber-400">
          <Zap size={18} />
          <h2 className="font-bold uppercase tracking-wider text-[10px]">Diagnostics</h2>
        </div>
        <div className="text-[10px] text-slate-600 space-y-2 mono">
          <p className="flex justify-between"><span>SERVICE</span> <span className="text-slate-400">Render</span></p>
          <p className="flex justify-between"><span>POLLING</span> <span className="text-slate-400">5s Interval</span></p>
          <p className="flex justify-between"><span>LIMIT</span> <span className="text-slate-400">50MB</span></p>
        </div>
      </div>
    </div>
  );
};

interface ParamSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix?: string;
  onChange: (val: number) => void;
}

const ParamSlider: React.FC<ParamSliderProps> = ({ label, value, min, max, step, suffix = '', onChange }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center">
      <span className="text-xs text-slate-400 font-semibold uppercase tracking-tight">{label}</span>
      <span className="text-xs text-indigo-400 font-bold mono">{value.toFixed(2)}{suffix}</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition-all"
    />
  </div>
);

export default ConfigSidebar;
