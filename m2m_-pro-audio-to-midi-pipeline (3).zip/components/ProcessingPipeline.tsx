
import React from 'react';
import { PipelineStatus } from '../types';
import { PIPELINE_STEPS } from '../constants';
import { CheckCircle2, Circle, Loader2, AlertCircle } from 'lucide-react';

interface ProcessingPipelineProps {
  status: PipelineStatus;
  progress: number;
  currentTask: string;
}

const ProcessingPipeline: React.FC<ProcessingPipelineProps> = ({ status, progress, currentTask }) => {
  const getStepStatus = (stepStatus: string) => {
    const statuses = Object.values(PipelineStatus);
    const currentIndex = statuses.indexOf(status);
    const stepIndex = statuses.indexOf(stepStatus as PipelineStatus);

    if (status === PipelineStatus.ERROR) return 'error';
    if (currentIndex > stepIndex) return 'completed';
    if (currentIndex === stepIndex) return 'current';
    return 'pending';
  };

  return (
    <div className="space-y-8 py-4">
      <div className="relative">
        {/* Progress Bar Background */}
        <div className="absolute top-4 left-4 right-4 h-0.5 bg-slate-800"></div>
        {/* Progress Fill */}
        <div 
          className="absolute top-4 left-4 h-0.5 bg-indigo-500 transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        ></div>

        <div className="flex justify-between relative">
          {PIPELINE_STEPS.map((step) => {
            const stepStatus = getStepStatus(step.status);
            return (
              <div key={step.status} className="flex flex-col items-center group">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 transition-all duration-300 ${
                  stepStatus === 'completed' ? 'bg-indigo-500 text-white' :
                  stepStatus === 'current' ? 'bg-slate-900 border-2 border-indigo-500 text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.5)]' :
                  stepStatus === 'error' ? 'bg-red-500 text-white' :
                  'bg-slate-800 border-2 border-slate-700 text-slate-500'
                }`}>
                  {stepStatus === 'completed' && <CheckCircle2 size={16} />}
                  {stepStatus === 'current' && <Loader2 size={16} className="animate-spin" />}
                  {stepStatus === 'pending' && <Circle size={12} fill="currentColor" />}
                  {stepStatus === 'error' && <AlertCircle size={16} />}
                </div>
                <span className={`mt-3 text-[10px] font-bold uppercase tracking-wider ${
                  stepStatus === 'current' ? 'text-indigo-400' : 'text-slate-500'
                }`}>
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-8 h-8">
             <div className="absolute inset-0 rounded-full border-2 border-slate-800"></div>
             <div 
               className="absolute inset-0 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin"
               style={{ animationDuration: '1s' }}
             ></div>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-300 uppercase tracking-tight">Active Operation</p>
            <p className="text-sm text-indigo-400 font-medium">{currentTask}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs font-semibold text-slate-500 uppercase">Progress</p>
          <p className="text-xl font-bold text-white mono">{Math.round(progress)}%</p>
        </div>
      </div>
    </div>
  );
};

export default ProcessingPipeline;
