
import React from 'react';
import { Download, Music, Share2, Play, Info, Layers } from 'lucide-react';
import { ProcessingState } from '../types';

interface ResultsPanelProps {
  state: ProcessingState;
  onReset: () => void;
}

const ResultsPanel: React.FC<ResultsPanelProps> = ({ state, onReset }) => {
  const { results } = state;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Result Header */}
        <div className="col-span-1 md:col-span-2 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Music className="text-white" size={28} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Pipeline Complete</h2>
              <p className="text-indigo-300 text-sm">Successfully generated MIDI with {results?.pedalCount} pedal events.</p>
            </div>
          </div>
          <button 
            onClick={onReset}
            className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold rounded-lg transition-colors"
          >
            Start New Project
          </button>
        </div>

        {/* Gemini Analysis */}
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-indigo-400 border-b border-slate-700/50 pb-3 mb-4">
            <Info size={18} />
            <h3 className="font-bold uppercase text-xs tracking-widest">Musical Insights (Gemini AI)</h3>
          </div>
          <div className="prose prose-invert prose-sm">
             <p className="text-slate-300 leading-relaxed italic">
               "{results?.analysis || 'Analyzing musical nuances...'}"
             </p>
          </div>
        </div>

        {/* Stats and Files */}
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 space-y-6">
          <div className="flex items-center gap-2 text-emerald-400 border-b border-slate-700/50 pb-3 mb-4">
            <Layers size={18} />
            <h3 className="font-bold uppercase text-xs tracking-widest">Output Artifacts</h3>
          </div>
          
          <div className="space-y-3">
             <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-700/50 group hover:border-indigo-500/50 transition-all">
                <div className="flex items-center gap-3">
                   <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center text-indigo-400">
                      <Music size={16} />
                   </div>
                   <span className="text-sm font-medium text-slate-300">transcription_pedal.mid</span>
                </div>
                <a 
                  href={results?.midiUrl} 
                  download="transcription.mid"
                  className="p-2 text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                >
                  <Download size={18} />
                </a>
             </div>

             {results?.wavUrl && (
                <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-700/50 group hover:border-emerald-500/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center text-emerald-400">
                      <Play size={16} fill="currentColor" />
                    </div>
                    <span className="text-sm font-medium text-slate-300">render_hq.wav</span>
                  </div>
                  <a 
                    href={results?.wavUrl} 
                    download="render.wav"
                    className="p-2 text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors"
                  >
                    <Download size={18} />
                  </a>
                </div>
             )}
          </div>

          <div className="pt-2">
             <button className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-indigo-500/20">
                <Share2 size={16} />
                Share Project
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPanel;
