
import { PedalParams, SoundFont } from './types';

export const DEFAULT_PEDAL_PARAMS: PedalParams = {
  sustainTolerance: 0.2,
  energySmooth: 0.5,
  lowFreqCut: 500,
  lowEnergyWeight: 0.6,
  fluxWeight: 0.4,
  onThreshold: 1.0,
  offThreshold: 0.7,
  minEventLen: 0.08,
  mergeGap: 0.08,
};

export const SF2_LIBRARY: SoundFont[] = [
  { id: 'grand-piano', name: 'Steinway Grand Piano', path: '/library/steinway.sf2' },
  { id: 'upright-piano', name: 'Classic Upright Piano', path: '/library/upright.sf2' },
  { id: 'rhodes', name: 'Vintage Electric Rhodes', path: '/library/rhodes.sf2' },
  { id: 'yamaha', name: 'Yamaha C7 Concert', path: '/library/yamaha.sf2' },
];

export const PIPELINE_STEPS = [
  { status: 'DOWNLOADING', label: 'Audio Acquisition' },
  { status: 'TRANSCRIBING', label: 'Transkun V2 AI Transcription' },
  { status: 'DETECTING_PEDALS', label: 'Rule-Based Pedal Analysis' },
  { status: 'INSERTING_CC', label: 'MIDI CC Injection' },
  { status: 'RENDERING', label: 'FluidSynth Rendering' },
];
