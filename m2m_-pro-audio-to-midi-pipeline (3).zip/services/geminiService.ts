
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Audio analysis for musical structure involves complex reasoning, so we use gemini-3-pro-preview.
export async function analyzeAudioWithGemini(fileBase64: string, mimeType: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: fileBase64,
              mimeType: mimeType
            }
          },
          {
            text: "Analyze this audio file for musical structure. Identify the instrument (likely piano), the genre, the complexity of the piece, and suggest if it needs heavy pedal processing. Provide a short, professional summary."
          }
        ]
      },
      config: {
        temperature: 0.7,
        topP: 0.95,
      }
    });

    // Directly access the text property as per the latest SDK guidelines.
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Analysis unavailable at the moment.";
  }
}

export async function suggestPedalParams(musicalSummary: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Based on this musical summary: "${musicalSummary}", suggest ideal sustain pedal parameters. Return only a short paragraph explaining why.`
      });
      return response.text;
    } catch (error) {
      return "Using standard default parameters.";
    }
}
