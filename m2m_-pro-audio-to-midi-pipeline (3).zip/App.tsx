
import React, { useState, useCallback, useMemo } from 'react';
import { PipelineStatus, ProcessingState, PedalParams } from './types';
import { DEFAULT_PEDAL_PARAMS } from './constants';
import { analyzeAudioWithGemini } from './services/geminiService';
import { ApiService } from './services/apiService';
import Header from './components/Header';
import ConfigSidebar from './components/ConfigSidebar';
import Uploader from './components/Uploader';
import ProcessingPipeline from './components/ProcessingPipeline';
import ResultsPanel from './components/ResultsPanel';
import { Music, AlertTriangle, RefreshCcw, Terminal, Code, Globe } from 'lucide-react';

const App: React.FC = () => {
  const [params, setParams] = useState<PedalParams>(DEFAULT_PEDAL_PARAMS);
  const [selectedSf2, setSelectedSf2] = useState('grand-piano');
  const [backendUrl, setBackendUrl] = useState('https://m2m-render-backend.onrender.com');
  const [state, setState] = useState<ProcessingState>({
    status: PipelineStatus.IDLE,
    progress: 0,
    currentTask: 'Waiting for input...'
  });

  const api = useMemo(() => new ApiService(backendUrl), [backendUrl]);

  const resetState = () => {
    setState({
      status: PipelineStatus.IDLE,
      progress: 0,
      currentTask: 'Waiting for input...'
    });
  };

  /**
   * 유튜브 URL 등으로부터 실제 음원 데이터를 추출하는 함수
   */
  const fetchAudioFromUrl = async (url: string): Promise<Blob> => {
    setState(prev => ({ ...prev, currentTask: '외부 URL에서 음원 데이터 추출 중...' }));
    
    // 실제 운영 환경에서는 유튜브 다운로드 전용 프록시 API(예: cobalt) 등이 필요할 수 있습니다.
    // 여기서는 일반적인 fetch 시도를 수행합니다.
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("URL 접근에 실패했습니다.");
      return await response.blob();
    } catch (err) {
      throw new Error("브라우저 보안(CORS) 정책으로 인해 URL에서 직접 음원을 추출할 수 없습니다. 파일을 직접 업로드해 주세요.");
    }
  };

  const processAudio = async (input: File | string) => {
    try {
      setState(prev => ({ 
        ...prev, 
        status: PipelineStatus.WAKING_UP, 
        progress: 2, 
        currentTask: '연결 확인 중...' 
      }));

      // 1. 입력이 URL인 경우 앱 내에서 먼저 다운로드 시도
      let audioBlob: File | Blob;
      if (typeof input === 'string') {
        audioBlob = await fetchAudioFromUrl(input);
      } else {
        audioBlob = input;
      }

      // 2. Gemini 분석 (비동기 병렬 실행)
      let musicalAnalysis = "Musical analysis pending...";
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(audioBlob);
      });
      const base64 = await base64Promise;
      analyzeAudioWithGemini(base64, audioBlob.type).then(res => { musicalAnalysis = res; });

      // 3. 파일 업로드 제출 (/submit/file)
      setState(prev => ({ 
        ...prev, 
        status: PipelineStatus.PROCESSING, 
        progress: 10, 
        currentTask: '서버로 음원 데이터 전송 중 (/submit/file)...' 
      }));
      
      const jobId = await api.startJob(audioBlob, params, selectedSf2);

      // 4. 폴링
      let completed = false;
      let attempts = 0;
      while (!completed && attempts < 300) {
        attempts++;
        const jobStatus = await api.pollStatus(jobId);

        if (jobStatus.status === 'done' && jobStatus.result) {
          completed = true;
          setState({
            status: PipelineStatus.DONE,
            progress: 100,
            currentTask: '성공적으로 완료되었습니다.',
            results: {
              midiUrl: api.getDownloadUrl(jobId, 'midi'),
              wavUrl: api.getDownloadUrl(jobId, 'wav'),
              analysis: musicalAnalysis,
              pedalCount: 0
            }
          });
        } else if (jobStatus.status === 'error') {
          throw new Error(jobStatus.error || jobStatus.message || '백엔드 처리 중 오류 발생');
        } else {
          setState(prev => ({
            ...prev,
            status: PipelineStatus.PROCESSING,
            progress: 10 + ((jobStatus.progress || 0) * 90),
            currentTask: `${jobStatus.step?.toUpperCase() || 'SERVER'}: ${jobStatus.message || '처리 중...'}`
          }));
          await new Promise(r => setTimeout(r, 5000));
        }
      }
    } catch (err: any) {
      setState(prev => ({
        ...prev,
        status: PipelineStatus.ERROR,
        error: err.message || '처리 중 예상치 못한 오류가 발생했습니다.'
      }));
    }
  };

  const handleProcess = useCallback((item: File | string) => {
    processAudio(item);
  }, [params, selectedSf2, backendUrl]);

  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden text-slate-200">
      <ConfigSidebar
        params={params}
        setParams={setParams}
        selectedSf2={selectedSf2}
        setSelectedSf2={setSelectedSf2}
        backendUrl={backendUrl}
        setBackendUrl={setBackendUrl}
        api={api}
      />

      <main className="flex-1 flex flex-col bg-slate-950 overflow-y-auto">
        <Header />

        <div className="max-w-4xl mx-auto w-full p-6 lg:p-12 space-y-12">
          {state.status === PipelineStatus.IDLE && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-500/10 rounded-2xl mb-4">
                  <Music className="text-indigo-500" size={32} />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight text-white lg:text-5xl">
                  Audio to <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-emerald-400">Pro MIDI</span>
                </h1>
                <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
                   URL 입력 시 앱 내에서 데이터를 추출하여 <span className="text-white font-mono">/submit/file</span>로 안전하게 전송합니다.
                </p>
              </div>
              <Uploader onProcess={handleProcess} isProcessing={false} />
            </div>
          )}

          {(state.status === PipelineStatus.WAKING_UP || state.status === PipelineStatus.PROCESSING) && (
            <div className="space-y-12 py-12 animate-in zoom-in-95 duration-300">
               <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-2">Processing Pipeline</h2>
                  <p className="text-slate-400 text-sm italic font-medium">{state.currentTask}</p>
               </div>
               <ProcessingPipeline 
                 status={state.status} 
                 progress={state.progress} 
                 currentTask={state.currentTask} 
               />
            </div>
          )}

          {state.status === PipelineStatus.DONE && <ResultsPanel state={state} onReset={resetState} />}

          {state.status === PipelineStatus.ERROR && (
            <div className="bg-red-500/5 border border-red-500/20 rounded-3xl p-8 md:p-12 text-center space-y-8 animate-in slide-in-from-top-4 duration-500">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto ring-8 ring-red-500/5">
                <AlertTriangle size={40} className="text-red-500" />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-white">Pipeline Failed</h3>
                <div className="text-red-400/90 text-sm bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-xl mx-auto whitespace-pre-wrap text-left font-mono leading-relaxed shadow-xl overflow-x-auto">
                  {state.error}
                </div>
              </div>
              <button onClick={resetState} className="bg-red-600 hover:bg-red-500 text-white px-8 py-3 rounded-xl font-bold flex items-center justify-center gap-2 mx-auto transition-all">
                <RefreshCcw size={18} /> Retry
              </button>

              <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 text-left max-w-xl mx-auto space-y-4">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-widest">
                  <Globe size={14} />
                  Note for URL Input
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  브라우저는 보안상 유튜브의 데이터를 직접 가져오는 것을 차단할 수 있습니다. <br/>
                  가장 확실한 방법은 <span className="text-white">음원 파일을 직접 업로드</span>하는 것입니다.
                </p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
