
export enum PipelineStatus {
  IDLE = 'IDLE',
  WAKING_UP = 'WAKING_UP',
  PROCESSING = 'processing', // 백엔드 worker.py와 일치
  DONE = 'done',             // 백엔드 worker.py와 일치
  ERROR = 'error'            // 백엔드 worker.py와 일치
}

// Added SoundFont interface to satisfy constants.ts import
export interface SoundFont {
  id: string;
  name: string;
  path: string;
}

export interface PedalParams {
  sustainTolerance: number;
  energySmooth: number;
  lowFreqCut: number;
  lowEnergyWeight: number;
  fluxWeight: number;
  onThreshold: number;
  offThreshold: number;
  minEventLen: number;
  mergeGap: number;
}

export interface ProcessingState {
  status: PipelineStatus;
  progress: number;
  currentTask: string;
  error?: string;
  results?: {
    midiUrl: string;
    wavUrl?: string;
    analysis?: string;
    pedalCount: number;
  };
}

export interface BackendResponse {
  job_id: string;
  status: 'processing' | 'done' | 'error';
  step: 'preprocessing' | 'transcribing' | 'rendering' | 'done' | 'error';
  progress: number;
  message: string;
  result?: {
    midi_path: string;
    wav_path: string;
  };
  error?: string;
}
